This archive contains unused demo code and components from the SpeedTUI library. 
The active application (Pmc.Strict) only uses the 'Core' engine and 'BorderHelper.ps1'.
Everything else in this archive (Screens, Models, Services, Components, Layouts, etc.) 
was part of the standalone SpeedTUI demo application and is dead code for the main project.

Archived on: Thu Dec 18 05:56:26 PM MST 2025
